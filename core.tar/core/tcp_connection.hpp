#pragma once

#include <cstddef>
class TcpConnection{
    public:
    // read finished callback
    void AfterRead(int fd, char* buf, size_t len) {
        
    }

    // write finished callback
    void AfterWrite(int fd, char* buf, size_t len) {

    }

    private:
    int connfd_;
};