//
// Created by tyx on 4/16/22.
//

#ifndef TINYRPC_PROACTOR_HPP
#define TINYRPC_PROACTOR_HPP
#include <core/addr.hpp>
#include <core/core.hpp>

#include <iostream>
#include <thread>
#include <type_traits>
#include <vector>

#include <common/thread.hpp>
namespace core {


template <is_net_stream netStreamT>
class Proactor {
  static size_t kMaxQueueSize;

 public:
  Proactor() : ring_(new io_uring) {
    io_uring_queue_init(kMaxQueueSize, ring_, 0);
  }

  

  static void SetRingQueueSize(size_t qsize) { kMaxQueueSize = qsize; }

  void Start() {
    common::Thread proactor("main_proactor", [this]() { EventLoop(); });
    proactor.detach();
  }

 private:
  void EventLoop() {
    
  }

  io_uring* ring_;
  pid_t tid_;
};

template <is_net_stream T>
size_t Proactor<T>::kMaxQueueSize = 16;
}  // namespace core
#endif  // TINYRPC_PROACTOR_HPP
