//
// Created by tyx on 4/4/22.
//
#pragma once
#ifndef TINYRPC_LINK_BUFFER_HPP
#define TINYRPC_LINK_BUFFER_HPP

#include <memory>
template <typename T>
concept is_allocator = requires(T v) {
  v.malloc();
};

template <is_allocator T>
struct LinkBufferNode {
  // buffer
  char* buf;
  // read-offset
  int off;
  // write-offset
  int malloc;
  // reference count
  int refer;
  // read-only node, introduced by Refer,WriteString, WriteBinary, etc., default
  // false
  bool readonly;
  LinkBufferNode* origin;
  // the next node of the linked buffer
  LinkBufferNode* next;
};

template <is_allocator T>
class LinkBuffer {
 private:
  int length_;
  int malloc_size_;
  std::shared_ptr<LinkBufferNode<T>> head_;
  std::shared_ptr<LinkBufferNode<T>> flush_;
  std::shared_ptr<LinkBufferNode<T>> write_;
  void* cache_;
};

#endif  // TINYRPC_LINK_BUFFER_HPP
