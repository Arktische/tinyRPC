#pragma once

#include <liburing.h>

#include <utility>
namespace core {
// One ProActor per thread, worker coroutines
// execute computation logic
template <typename streamT>
concept is_net_stream = requires(streamT stream, char* buf, int fd,
                                 size_t len) {
  stream.AfterRead(buf, len);
  stream.AfterWrite(buf, len);
  stream(fd);
};

template <typename T>
concept is_allocator = requires(T v) {
  v.malloc();
};

template <typename T>
concept is_stream_buffer = requires(T v) {
  v.malloc();
};

template <typename T>
concept is_net_addr = requires(T v) {
  v.sock_addr_ptr;
  v.socklen;
  v.socklen_ptr;
  v.string();
  v.af_family;
};

}  // namespace core