#pragma once
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>

#include <cstdint>
#include <cstring>
#include <string>
#include <string_view>

#include <core/core.hpp>
namespace core {
struct IPAddress {
  IPAddress(uint16_t port) {
    memset(&sock_addr, 0, sizeof(sock_addr));
    sock_addr.sin_family = AF_INET;
    sock_addr.sin_addr.s_addr = INADDR_ANY;
    sock_addr.sin_port = htons(port);
  }

  IPAddress(std::string_view ip, uint16_t port) {
    memset(&sock_addr, 0, sizeof(sock_addr));
    sock_addr.sin_family = AF_INET;
    sock_addr.sin_addr.s_addr = inet_addr(ip.data());
    sock_addr.sin_port = htons(port);
  }

  std::string string() {
    return std::string(inet_ntoa(sock_addr.sin_addr));
  }
  
  sockaddr_in* sock_addr_ptr{&sock_addr};
  socklen_t socklen{sizeof(sock_addr)};
  socklen_t* socklen_ptr{&socklen};
  private:
  sockaddr_in sock_addr;
  
};
}  // namespace core